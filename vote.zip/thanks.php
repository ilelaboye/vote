<?php 
require_once 'server/server.php';
	if ($_SESSION['count'] != 'true') {
		header('loation:index.php');
		exit();
	}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Company name
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!-- CSS Files -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>
<body class="off-canvas-sidebar">
  <div class="wrapper wrapper-full-page" style="">
    <div class="page-header register-page header-filter" filter-color="black" style="background-image: url('assets/img/register.jpg')">
      <div class="container">
        <div class="row">
          <div class="col-md-10 ml-auto mr-auto">
            <div class="card card-profile">
              <div class="card-body">
                <?php
                	if (isset($_SESSION['thanks'])) {
                		echo $_SESSION['thanks'];
                	}
                ?> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="assets/js/core/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
</body>

</html>