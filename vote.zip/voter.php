<?php 
  require_once 'server/server.php';
  $select = new validate;
  $select = $select->selectAll();
  $select = $select->fetchAll(2);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="description" content="">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Icons fashion show and awards 2019</title>
  <link rel="stylesheet" href="assets2/css/style.css">
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <style type="text/css">
    .owl-carousel .single-hero-post .hero-slides-content a{
      border:1px solid #E5C12F !important;
      border-radius: 4px;
      font-size: 20px;
      
      padding: 10px 35px;
      color: #fff;
      font-family: 'Merriweather', serif;
    }
    .owl-carousel .single-hero-post .hero-slides-content a:hover{
      background-color: #E5C12F;
      color: #111;
    }
    .card .card-body a:hover{
      transition: 0.5s;
      color: #fff !important;
    }
  </style>
</head>
<body>
  <header class="header-area">
      <!-- Top Header Area -->
      <div class="top-header">
          <div class="container">
              <div class="row">
                  <div class="col-12">
                      <div class="top-header-content d-flex align-items-center justify-content-between">
                          <a href="index.html" class="nav-brand"><img src="assets/img/kad.jpg" alt="" style="height: 35px;"></a>

                          <!-- Social Button -->
                          <div class="top-social-info">
                              <a href="https://Fb.me/theiconsfashionshow"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                             
                              <a href="www.instagram/theiconsfashionshowandaward"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </header>

  <section class="hero-area">
    <div class="hero-post-slides owl-carousel">
      <div class="single-hero-post">
          <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img1.jpg);"></div>
          <div class="hero-slides-content">
              <a href="voter.php" class="vote">
                  Vote Now
              </a>
          </div>
      </div>
      <div class="single-hero-post">
          <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img2.jpg);"></div>
          <div class="hero-slides-content">
              <a href="voter.php" class="vote">
                  Vote Now
              </a>
          </div>
      </div>
      <div class="single-hero-post">
          <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img3.jpg);"></div>
          <div class="hero-slides-content">
              <a href="voter.php" class="vote">
                  Vote Now
              </a>
          </div>
      </div>
      <div class="single-hero-post">
          <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img4.jpg);"></div>
          <div class="hero-slides-content">
              <a href="voter.php" class="vote">
                  Vote Now
              </a>
          </div>
      </div>
      <div class="single-hero-post">
          <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img5.jpg);"></div>
          <div class="hero-slides-content">
              <a href="voter.php" class="vote">
                  Vote Now
              </a>
          </div>
      </div>
      <div class="single-hero-post">
        <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img6.jpg);"></div>
        <div class="hero-slides-content">
          <a href="voter.php" class="vote">
              Vote Now
          </a>
        </div>
      </div>
    </div>
  </section>

  <div class="container-fluid">
    <div class="row">
      <?php
        foreach ($select as $value) { ?>
          <div class="col-md-6" style="margin-top: 80px;">
        <div class="card card-profile">
          <div class="card-avatar">
            <a href="#pablo">
              <img class="img" src="<?php echo 'assets/img/upload/'.$value['img'] ?>" />
            </a>
          </div>
          <h2 id="thanks" style="color:#E5C12F;"></h2>
          <div class="card-body">
            <h3 class="card-title">Vote</h3>
            <h2 class="card-title" style="text-transform: capitalize;" id="nameC"><?php echo $value['name'] ?></h2>
            <h5>as</h5>
            <h4 class="card-category" style="color:#E5C12F; font-size: 20px; text-transform: capitalize;font-weight: bold;"><?php echo $value['category'] ?></h4>
            
            <p class="card-description">
              <?php echo $value['description'] ?> 
            </p> 
            <a href="vote.php?token=<?php echo($value['token']) ?>" class="btn btn-rose btn-round" style="width: 20em; background-color: #E5C12F; color: #111; font-weight: bold;"> Vote Now</a>
            <!-- <form action="" method="post">
              <input type="hidden" id="class" class="buttonClass" name="token" value="<?php echo $value['token'] ?>" >
              <input type="submit" class="btn btn-rose btn-round" id="buttonId" name="vote_count" value="Vote" style="width: 20em; background-color: #E5C12F; color: #111; font-weight: bold;" id="submit" onclick="allow();">
            </form>  -->
          </div>
        </div>
      </div>
      <?php  }
      ?>
      
    </div>
  </div>


  <div class="" style="text-align: center; margin-top: 30px;">
      <h3>Sponsored By</h3>
      <img src="assets/img/kad.jpg" style="height: 40px;">
      <img src="assets/img/kad2.jpg" style="height: 40px;">
  </div>

  <p style="float: right; margin-right: 100px;">Made  with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#">&lt/DevLekan&gt</a></p>
  <script src="assets2/js/jquery/jquery-2.2.4.min.js"></script>
  <!-- Popper js -->
  <script src="assets2/js/bootstrap/popper.min.js"></script>
  <!-- Bootstrap js -->
  <script src="assets2/js/bootstrap/bootstrap.min.js"></script>
  <!-- All Plugins js -->
  <script src="assets2/js/plugins/plugins.js"></script>
  <!-- Active js -->
  <script src="assets2/js/active.js"></script>
</body>
</html>