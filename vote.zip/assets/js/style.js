$(document).ready(function(){
	// $(window).on('load', ()=>{
 //      if (localStorage.getItem('getToken')) {
 //        $('#buttonId').attr('disabled','true');
 //      }
 //    });
 	var getToken=document.getElementById('class').value;
	if (localStorage.getItem(document.getElementById('class').value)) {
        $('.page-header1').css('display', 'block');
 		$('.mine').css('display', 'none');
 		 $('#button').attr('disabled','true');
        $('#buttonId').css('display', 'none');
        $('#displayModal').css('display','content');
 		console.log('trial');
    }else{
    	$('#id').css('display','none');
    }
	console.log('lemn');

	$('#buttonId').on('click', (e)=>{
		console.log('logged');
	    e.preventDefault();
	    
	    var nameC=document.getElementById('thanks');
	    nameC.innerHTML = 'Thanks For Voting';
	    console.log(nameC);
	    $.post("../vote/server/call.php",{key:getToken},function(data){
	    	localStorage.setItem(document.getElementById('class').value, getToken);
	    	$('#buttonId').attr('disabled', 'true');
	    	
    	});
    
  	});
});