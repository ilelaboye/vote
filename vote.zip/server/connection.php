<?php
	/**
	 * 
	 */
	class dbconnect 
	{
		protected $db_conn;
		public $db_user='root';
		public $db_pass='freshfire';
		
		
		function connect()
		{
			try{
				$this->db_conn=new PDO('mysql:host=127.0.0.1;dbname=vote',$this->db_user,$this->db_pass);
				return $this->db_conn;
			}
			catch(PDOException $e){
				return $e->getMessage();
			}
		}
	}
?>