<?php
	session_start(); 
	require_once 'connection.php';

	class validate
	{
		public $link;
		
		function __construct(){
			$db_conn = new dbconnect();
			$this->link = $db_conn->connect();
			return $this->link;
		}
		function post_validate(){
			$email=trim($_POST['email']);
			$email=htmlspecialchars($email);
			$name = htmlspecialchars($_POST['name']);
			$category=htmlspecialchars(strtolower(trim($_POST['category'])));
			$phone=htmlspecialchars($_POST['number']);
			$password=$_POST['password'];
			$password=password_hash($password, PASSWORD_DEFAULT);
			$list=['!','%','£','^','<','>','&','*','$','(',')','_','-','=','+','{','[','}',']','#','~',';',':',',','?','/','¬'];
			if (empty($email) || empty($name) || empty($password) || empty($category)) {
				$_SESSION['msg']='Input Field is Required';
				header('location:../register.php');
				exit();
			}
			foreach ($list as $value) {
				if(stristr($email, $value) || stristr($name, $value)){
					$_SESSION['msg']='Input Field should not contain any character';
					header('location:../register.php');
					exit();
				}
			}
			$check=$this->link->query("SELECT * FROM candidate WHERE email='$email'");
			if ($check->rowCount() > 0) {
				$_SESSION['msg'] = 'Email already exist';
				header('location:../register.php');
				exit();
			}
			$var= trim(str_shuffle(md5($name)));
			$token = substr($var, 0, 7);
			
			$insert="INSERT INTO candidate (id,name,phone_no,email,password,category,token) VALUES (NULL,?,?,?,?,?,?)";
			$count="INSERT INTO vote_count (id,token,vote,email,category,name) VALUES (NULL,?,?,?,?,?)";

				//insert into the vote_count table 
			$v_count=$this->link->prepare($count);	
				//insert into the candidate table
			$query = $this->link->prepare($insert);
				

			$selectS = $this->link->query("SELECT * FROM category WHERE category='$category' LIMIT 1");
			if ($selectS->rowCount() == 0) {
				//insert into the category table
				$cat="INSERT INTO category (id,category) VALUES (NULL,?)";
				$Fcategory=$this->link->prepare($cat);
				$Fcategory->execute(array($category));	
			}
			
			
			
			if($query->execute(array($name,$phone,$email,$password,$category,$token)) &&  $v_count->execute(array($token,0,$email,$category,$name))){
				$_SESSION['active'] = 'true';
				$_SESSION['log_email']=$email;
				header('location:../candidate.php');
				exit();
			}
		}
		function selectCategory(){
			$select=$this->link->query("SELECT * FROM category");
			return $select;
		}
		function selectAll(){
			$select=$this->link->query("SELECT * FROM candidate JOIN vote_count ON candidate.email = vote_count.email");
			return $select;
		}
		function callAll(){
			$select=$this->link->query("SELECT * FROM candidate");
			return $select;
		}
		function vote_no($token){
			$select=$this->link->query("SELECT vote FROM vote_count WHERE token='$token' LIMIT 1");
			return $select;	
		}
		function login(){
			$email = $_POST['email'];
			$password=$_POST['password'];
			$list=['!','%','£','^','<','>','&','*','$','(',')','_','-','=','+','{','[','}',']','#','~',';',':',',','?','/','¬'];
			foreach ($list as $value) {
				if(stristr($email, $value)){
					$_SESSION['msg']='Input Fields should not contain any character';
					header('location:../index.php#form');
					exit();
				}
			}
			$check=$this->link->query("SELECT * FROM candidate WHERE email='$email' LIMIT 1");
			if ($check->rowCount() == 0) {
				$_SESSION['msg']='Email not found';
				header('location:../index.php#form');
				exit();
			}
			$log=$check->fetch(2);
			//echo $log['password'];
			if (!password_verify($password, $log['password'])) {
				$_SESSION['msg']='Invalid Email and Password';
				header('location:../index.php#form');
				exit();
			}

			$_SESSION['active']='true';
			$_SESSION['log_email'] = $email;
			header('location:../candidate.php');
			exit();			
		}
		function adminLogin(){
			$email = $_POST['email'];
			$password=$_POST['password'];
			$list=['!','%','£','^','<','>','&','*','$','(',')','_','-','=','+','{','[','}',']','#','~',';',':',',','?','/','¬'];
			foreach ($list as $value) {
				if(stristr($email, $value)){
					$_SESSION['msg']='Input Fields should not contain any character';
					header('location:../adminSide/adminindex.php');
					exit();
				}
			}
			$check=$this->link->query("SELECT * FROM adminuser WHERE email='$email' LIMIT 1");
			if ($check->rowCount() == 0) {
				$_SESSION['msg']='Email not found';
				header('location:../adminSide/adminindex.php');
				exit();
			}
			$log=$check->fetch(2);
			//echo $log['password'];
			if (!password_verify($password, $log['password'])) {
				$_SESSION['msg']='Invalid Email and Password';
				header('location:../adminSide/adminindex.php');
				exit();
			}

			$_SESSION['active']='true';
			header('location:../adminSide/adminPage.php');
			exit();			
		}
		function candidate($token='',$email=''){
			$select = $this->link->query("SELECT * FROM candidate WHERE email='$email' OR token='$token' LIMIT 1");
			return $select;
		}
		function update(){
			if (empty($_POST['description'])) {
				$_SESSION['can_msg']='Input all field';
				header('location:../candidate.php');
				exit();
			}
			$desc=htmlspecialchars($_POST['description']);

			$var = new validate;
			$var = $var->candidate($_POST['token']);
			$fetch= $var->fetch(2);

			$_SESSION['active'] = 'true';
			$_SESSION['log_email']=$fetch['email'];
			$email=$fetch['email'];
			$tar='assets/img/upload/';
			
			$name = basename($_FILES['img']['name']);
			$rand = rand(1,200).'.';
			$cut=str_replace('.',$rand, $name);

			$destination=$tar . $cut;
			$type=pathinfo($destination, PATHINFO_EXTENSION);
			$destination = '../'.$destination;
			$accept=['jpg','png','jpeg','JPEG','JPG','PNG'];
			if (!in_array($type, $accept)) {
				$_SESSION['can_msg']="Invalid Image Format";
				header('location:../candidate.php');
				exit();
			}
			if ($_FILES['img']['size'] > 500000000) {
				$_SESSION['can_msg']="Image size must not be greater than 5mb";
				header('location:../candidate.php');
				exit();
			}
			// echo $destination;
			// var_dump($_FILES['img']);
			// exit();
			if (!move_uploaded_file($_FILES['img']['tmp_name'], $destination)) {
				$_SESSION['can_msg'] = "Image not Uploaded Try again later";
				header('location:../candidate.php');
				exit();
			}
			$sql = "UPDATE candidate SET img='$cut',description='$desc' WHERE email='$email'";
			$upload=$this->link->prepare($sql);
			if (!$upload->execute()) {
				$_SESSION['can_msg'] = 'Image not Uploaded,Try again later';
				header('location:../candidate.php');
				exit();	
			}
			$_SESSION['can_msg'] = 'Profile Uploaded Successfully';
			header('location:../candidate.php');
			exit();
		}
		function logout(){
			session_unset();
			session_destroy();
			header('location:../index.php');
			exit();
		}
		function adminLogout(){
			session_unset();
			session_destroy();
			header('location:../adminSide/adminindex.php');
			exit();
		}
		function vote_count(){
			$_SESSION['count'] = 'true';
			$token=htmlspecialchars($_POST['key']);
			$select="SELECT vote FROM vote_count WHERE token='$token' LIMIT 1";
			$select=$this->link->prepare($select);
			$finish=$select->execute();
			if (!$finish) {
				$_SESSION['thanks']='Vote not counted, Please check the link and try again later';
				header('location:../index.php');
				exit();
			}
 
			if ($select->rowCount() < 1) {
				$_SESSION['thanks'] = 'User not found, Please check the link and try again';
				header('location:../vote.php');
				exit();
			}
			$result=$select->fetch(2);
			$counter = $result['vote'];
			$add = $counter + 1;
			$update = "UPDATE vote_count SET vote = '$add' WHERE token='$token'";
			$final = $this->link->prepare($update);
			if (!$final->execute()) {
				$_SESSION['thanks'] = 'Vote not counted, Please try again';
				header('location:../thanks.php');
				exit();
			}
			$_SESSION['thanks'] = 'Thanks For Voting';
			return $_SESSION['thanks'];
			// header('location:../thanks.php');
			// exit();
		}
		function max($category){
			$sel="SELECT MAX(vote) As counter FROM vote_count WHERE category = '$category'";
			$sel=$this->link->prepare($sel);
			if ($sel->execute()) {
				$all=$sel->fetch(2);
				$ask= $all['counter'];
				$her="SELECT * FROM vote_count WHERE category = '$category' AND vote='$ask'";
				$her=$this->link->prepare($her);
				if ($her->execute()) {
					$fetch=$her->fetch(2);
					return $fetch;
				}
			}
		}
	}	
?>
