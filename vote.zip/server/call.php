<?php
	require_once 'server.php';
	if (!isset($_POST['reg_submit']) && !isset($_POST['login']) && !isset($_POST['logout']) && !isset($_POST['update_submit']) && !isset($_POST['vote_count']) && !isset($_POST['key'])  && !isset($_POST['adminLogin']) && !isset($_POST['adminLogout'])) {
		$_SESSION['msg'] = 'Please Login or Register';
		// echo "Pllease Login or Regis";
		exit();
	}
	if (isset($_POST['reg_submit'])) {
		// $_SESSION['active'] = 'Registeration Complete';
		$user= new validate;
		$user->post_validate();
	}
	if (isset($_POST['login'])) {
		$login=new validate;
		$login->login();
	}
	if (isset($_POST['adminLogin'])) {
		$login=new validate;
		$login->adminLogin();
	}
	if (isset($_POST['logout'])) {
		$logout = new validate;
		$logout->logout();
	}
	if (isset($_POST['adminLogout'])) {
		$logout = new validate;
		$logout->adminLogout();
	}
	if (isset($_POST['update_submit'])) {
		$update = new validate;
		$update->update();
	}

	if(isset($_POST['key'])){
		
		$counter = new validate;
		$counter->vote_count();
	}
?>