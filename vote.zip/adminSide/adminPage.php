<?php
  require_once '../server/server.php';
  if ($_SESSION['active'] != 'true') {
    header('location:adminLogin.php');
    exit();
  }
  $all = new validate;

  $selectCat = $all->selectCategory();
  $selectCat2 = $selectCat->fetchAll(2);
  $c_counter = $selectCat->rowCount();
  //select all data from cadidate and vote counter
  $selectAll = $all->selectAll();
  $selectAll2 = $selectAll->fetchAll(2);
  // var_dump($selectAll2);
  $u_counter = $selectAll->rowCount();

  //select candidate with highest vote
  // $miami=$all->max('miami');
  // $miami=$miami->fetch(2);
  
  // $bucharest=$all->max('bucharest');
  // $bucharest=$bucharest->fetch(2);

  // $paris=$all->max('paris');
  // $paris=$paris->fetch(2);

  // $rome=$all->max('rome');
  // $rome=$rome->fetch(2);

  // $new_york=$all->max('new_york');
  // $new_york=$new_york->fetch(2);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Company name
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>

<body class="off-canvas-sidebar" style="background-image: url('../assets/img/register.jpg'); background-size: cover;">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
    <div class="container">
      <div class="navbar-wrapper">
        <a class="navbar-brand" href="">Admin Page</a>
      </div>
      <ul class="nav navbar-nav navbar-right">
        <li class="nav-item  active ">
          <a href="../register.php" class="nav-link">
            <i class="material-icons">person_add</i> Register
          </a>
        </li>
        <li>
          <form action="../server/call.php" method="post">
            <input type="submit" name="adminLogout" value="Logout" style="border: none; background: transparent; color: white;">
          </form>
        </li>
      </ul>
    </div>
  </nav>
  <div class="wrapper wrapper-full-page" style="">
    <div class="page-header register-page header-filter" filter-color="black">
      <div class="container">
        <div class="row">
          <?php 
            for ($i=0; $i < $c_counter; $i++) { ?>
              <div class="col-md-3 ml-auto mr-auto">
                <div class="card card-profile">
                  <h4 class="card-title" style="margin-top: 20px;"> <?php $holder=$selectCat2[$i]['category']; echo $holder ?></h4>
                  <div class="card-title">    
                    <h1 style="margin-top: 0;">
                      <?php  
                        $fet = $all->max($holder);
                        echo $fet['vote'];
                      ?>  
                    </h1>
                  </div>
                  <p class="card-description" style="margin-bottom: 0px;">
                    Number of Votes
                  </p>
                  <h4 class="card-title" style="margin-top: 20px; margin-bottom: 20px;">
                    <?php 
                      
                      echo $fet['name'];
                    ?>
                  </h4>
                </div> 
              </div>
    <?php   } ?>
               
          
          <!-- <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-profile">
              <h4 class="card-title" style="margin-top: 20px;">Paris</h4>
              <div class="card-title">
                <h1 style="margin-top: 0;"><?php echo $paris['vote']; ?> </h1>
              </div>
              <p class="card-description" style="margin-bottom: 0px;">
                Number of Votes
              </p>
              <h4 class="card-title" style="margin-top: 20px; margin-bottom: 20px;"><?php echo $paris['name']; ?></h4>
            </div> 
          </div>
          <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-profile">
              <h4 class="card-title" style="margin-top: 20px;">New York</h4>
              <div class="card-title">
                <h1 style="margin-top: 0;"><?php echo $new_york['vote']; ?></h1>
              </div>
              <p class="card-description" style="margin-bottom: 0px;">
                Number of Votes
              </p>
              <h4 class="card-title" style="margin-top: 20px; margin-bottom: 20px;"><?php echo $new_york['name']; ?></h4>
            </div> 
          </div>
          <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-profile">
              <h4 class="card-title" style="margin-top: 20px;">Rome</h4>
              <div class="card-title">
                <h1 style="margin-top: 0;"> <?php echo $rome['vote']; ?></h1>
              </div>
              <p class="card-description" style="margin-bottom: 0px;">
                Number of Votes
              </p>
              <h4 class="card-title" style="margin-top: 20px; margin-bottom: 20px;"><?php echo $rome['name']; ?></h4>
            </div> 
          </div>
          <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-profile">
              <h4 class="card-title" style="margin-top: 20px;">Miami</h4>
              <div class="card-title">    
                <h1 style="margin-top: 0;"><?php echo $miami['vote']; ?></h1>
              </div>
              <p class="card-description" style="margin-bottom: 0px;">
                Number of Votes
              </p>
              <h4 class="card-title" style="margin-top: 20px; margin-bottom: 20px;"><?php echo $miami['name']; ?></h4>
            </div> 
          </div> -->
        </div>
      </div>      
    </div>
    <div class="container-fluid table-responsive card">
      <table class="table" style="color: black;">
        <tr style="font-weight: bolder; font-size: 16px;" class="card-title">
          <th>Name</th>
          <th>Email</th>
          <th>Category</th>
          <th>Vote</th>
          <th>Description</th>
        </tr>
        <?php
          for ($i=0; $i <$u_counter; $i++) { ?>
            <tr>
              <th><?php echo $selectAll2[$i]['name'] ?></th>
              <th><?php echo $selectAll2[$i]['email'] ?></th>
              <th><?php echo $selectAll2[$i]['category'] ?></th>
              <th><?php echo $selectAll2[$i]['vote'] ?></th>
              <th><?php echo $selectAll2[$i]['description'] ?></th>
        <?php  } ?>
      </table>
    </div>
  </div>
    
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="../assets/js/plugins/bootstrap-selectpicker.js"></script>
  <script src="../assets/js/material-dashboard.js?v=2.1.0" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      md.checkFullPageBackgroundImage();
    });
  </script>
</body>
</html>
