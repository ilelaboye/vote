<?php 
 require_once 'server/server.php';
 // echo $_SESSION['active'];
  if ($_SESSION['active'] != 'true') {
    header('location:index.php');
    exit();
  }
  $email=$_SESSION['log_email'];
  $user = new validate();
  $cand = $user->candidate('',$email);
  $cand= $cand->fetch(2);

  $vote_no = $user->vote_no($cand['token']);
  $vote_no=$vote_no->fetch(2);

  
  $token='vote.php?token='.$cand['token'];


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Company name
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
</head>

<body class="off-canvas-sidebar">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top text-white">
    <div class="container">
      <div class="navbar-wrapper">
        <a class="navbar-brand" href="">Home</a>
      </div>
      <ul class="nav navbar-nav navbar-right">
        <li>
          <form action="server/call.php" method="post">
            <input type="submit" name="logout" value="Logout" style="border: none; background: transparent; color: white;">
          </form>
        </li>
      </ul>
    </div>
  </nav>
  <!-- End Navbar -->
  <div class="wrapper wrapper-full-page" style="">
    <div class="page-header register-page header-filter" filter-color="black" style="background-image: url('assets/img/register.jpg')">
      <div class="container">
        <div class="row" style="">
          <div class="col-md-8 ml-auto mr-auto">
            <div class="card card-profile">
              <div class="card-avatar">
                <a href="#pablo">
                  <img class="img" src="assets/img/upload/<?php echo $cand['img'] ?>" />
                </a>
              </div>
              <div class="card-body">
                <h6 class="card-category text-gray"><?php echo $cand['category']; ?></h6>
                <h2 class="card-title" style="text-transform: capitalize;"><?php echo $cand['name']; ?></h2>
                <p class="card-description">
                  <?php echo $cand['description']; ?>
                </p>

              </div>
            </div> 
          </div>
          <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-profile" >
              <div class="card-title">
                <h1 style="margin-top: 55px;"><?php echo $vote_no['vote']; ?></h1>
              </div>
              <p class="card-description" style="margin-bottom: 0px;">
                Number of Votes
              </p>
              <h4 class="card-title" style="margin-top: 20px;">Your Token</h4>
              <a href= "<?php echo $token; ?>"  style="color: #ec407a; font-size: 20px; font-weight: bold; margin-bottom: 25px; margin-top: 10px;"> <?php echo $token ?> </a>
            </div> 
          </div>

          <div class="col-md-10 ml-auto mr-auto">
            <div class="card">
              <div class="card-header card-header-icon card-header-rose">
                <div class="card-icon">
                  <i class="material-icons">perm_identity</i>
                </div>
                <h4 class="card-title">Edit Profile</h4>
              </div>
              <div class="card-body">
                <form action="server/call.php" method="post" enctype="multipart/form-data">
                  <?php 
                    if(isset($_SESSION['can_msg'])){ ?>
                      <div class="card error" style="color: white; border-radius: 0px; background: linear-gradient(60deg, #ec407a, #d81b60); text-align: center; font-size: 17px; padding-top: 5px; padding-bottom: 5px;">
                        <?php echo $_SESSION['can_msg']; ?>
                      </div>
                    <?php 
                    //session_unset(); 
                    //if i refresh it redirect back to login page bcos i have unset all session dat is why i comment it  
                      }
                    ?>
                  
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group">
                        <label for="about">About Me</label>
                        <div class="form-group">
                          <label class="bmd-label-floating"> Let your fans know more about you.</label>
                          <textarea class="form-control" rows="5" id="about" name="description"></textarea>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <input type="file" name="img" value="Select Image" class="btn btn-rose btn-round btn-file">                      
                    </div>
                  </div>
                  <input type="hidden" name="token" value="<?php echo($cand['token']) ?>">
                  <button type="submit" name="update_submit" class="btn btn-rose">Update Profile</button>
                  <div class="clearfix"></div>
                </form>
              </div>
              
            </div>
        </div>
      </div>
      <div class="" style="text-align: center;">
        <h3>Sponsored By</h3>
        <img src="assets/img/kad.jpg" height="30px">
        <img src="assets/img/kad2.jpg" height="30px">
      </div>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="assets/js/core/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <script src="assets/js/plugins/bootstrap-selectpicker.js"></script>
  <script src="assets/js/material-dashboard.js?v=2.1.0" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      md.checkFullPageBackgroundImage();
    });
  </script>
</body>

</html>