-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 26, 2019 at 11:18 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vote`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

DROP TABLE IF EXISTS `adminuser`;
CREATE TABLE IF NOT EXISTS `adminuser` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '$2y$10$Jf7hLXHmOuYS19/mK1mSguYOXYPsjyuqCEmyBt2j9yowR0B45FEvG');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

DROP TABLE IF EXISTS `candidate`;
CREATE TABLE IF NOT EXISTS `candidate` (
  `id` int(225) NOT NULL AUTO_INCREMENT,
  `name` varchar(225) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `category` varchar(225) NOT NULL,
  `token` varchar(100) NOT NULL,
  `img` varchar(100) NOT NULL DEFAULT 'default-avatar.png',
  `description` varchar(100) NOT NULL DEFAULT 'What your fans should know about you',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`id`, `name`, `phone_no`, `email`, `password`, `category`, `token`, `img`, `description`) VALUES
(1, 'lekan', '09403000494', 'lekan@gmail.com', '$2y$10$9aqM3iePNpi77B0bZfwuWuXqrifX5AgOh8Ai78HYoH/SpnC3dz0DS', 'highdee', '7fc4f33', '11162.jpg', 'Hello'),
(2, 'ilelaboye lekan', '09403000494', 'lekan2@gmail.com', '$2y$10$BmrdHxmvxyLxwRVIr9SO.erjFSbRkGZgL9VaKPKryj9A2AG71IDZ6', 'fashion', '869a830', 'default-avatar.png', 'What your fans should know about you'),
(3, 'deji', '09403000494', 'deji@gmail.com', '$2y$10$ygDodaDIxBOZomIoZ9Gp/eXGsP46cpSyygXRstdBt9jijUST66Fd.', 'deji', '3597a46', 'default-avatar.png', 'What your fans should know about you'),
(4, 'highdee', '09403000494', 'ade@gmail.com', '$2y$10$txSME23WuZr4BVoTjew/L.3z1r5/Wq/FJMdx8HhuQZDyYAknidPa2', 'highdee', 'af0239b', 'default-avatar.png', 'What your fans should know about you');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(225) NOT NULL AUTO_INCREMENT,
  `category` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(1, 'highdee'),
(2, 'fashion'),
(3, 'deji');

-- --------------------------------------------------------

--
-- Table structure for table `vote_count`
--

DROP TABLE IF EXISTS `vote_count`;
CREATE TABLE IF NOT EXISTS `vote_count` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `token` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `vote` int(200) NOT NULL DEFAULT '0',
  `category` varchar(255) NOT NULL,
  `name` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vote_count`
--

INSERT INTO `vote_count` (`id`, `token`, `email`, `vote`, `category`, `name`) VALUES
(1, '7fc4f33', 'lekan@gmail.com', 1, 'highdee', 'lekan'),
(2, '869a830', 'lekan2@gmail.com', 0, 'fashion', 'ilelaboye lekan'),
(3, '3597a46', 'deji@gmail.com', 1, 'deji', 'deji'),
(4, 'af0239b', 'ade@gmail.com', 1, 'highdee', 'highdee');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
