
<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Icons fashion show and awards 2019</title>
    <link rel="stylesheet" href="assets2/css/style.css">

  <style type="text/css">
    .owl-carousel .single-hero-post .hero-slides-content a{
      border:1px solid #E5C12F !important;
      border-radius: 4px;
      font-size: 20px;
    
      padding: 10px 35px;
      color: #fff;
      font-family: 'Merriweather', serif;
    }
    .owl-carousel .single-hero-post .hero-slides-content a:hover{
      background-color: #E5C12F;
      color: #111;
    }
  </style>
</head>
<body>

    <header class="header-area">
        <!-- Top Header Area -->
        <div class="top-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="top-header-content d-flex align-items-center justify-content-between">
                            <a href="index.html" class="nav-brand"><img src="assets/img/kad.jpg" alt="" style="height: 35px;"></a>

                            <!-- Social Button -->
                            <div class="top-social-info">
                                <a href="https://Fb.me/theiconsfashionshow"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                               
                                <a href="www.instagram/theiconsfashionshowandaward"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    

    <section class="hero-area">
      <div class="hero-post-slides owl-carousel">
          <!-- Single Hero Post -->
          <div class="single-hero-post">
              <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img1.jpg);"></div>
              <div class="hero-slides-content">
                  <a href="voter.php" class="vote">
                      Vote Now
                  </a>
              </div>
          </div>

          <!-- Single Hero Post -->
          <div class="single-hero-post">
              <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img2.jpg);"></div>
              <div class="hero-slides-content">
                  <a href="voter.php" class="vote">
                      Vote Now
                  </a>
              </div>
          </div>

          <!-- Single Hero Post -->
          <div class="single-hero-post">
              <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img3.jpg);"></div>
              <div class="hero-slides-content">
                  <a href="voter.php" class="vote">
                      Vote Now
                  </a>
              </div>
          </div>

          <!-- Single Hero Post -->
          <div class="single-hero-post">
              <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img4.jpg);"></div>
              <div class="hero-slides-content">
                  <a href="voter.php" class="vote">
                      Vote Now
                  </a>
              </div>
          </div>

          <!-- Single Hero Post -->
          <div class="single-hero-post">
              <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img5.jpg);"></div>
              <div class="hero-slides-content">
                  <a href="voter.php" class="vote">
                      Vote Now
                  </a>
              </div>
          </div>

          <!-- Single Hero Post -->
          <div class="single-hero-post">
              <div class="slide-img bg-img" style="background-image: url(assets2/img/blog-img/img6.jpg);"></div>
              <div class="hero-slides-content">
                <a href="voter.php" class="vote">
                    Vote Now
                </a>
              </div>
      </div>
    </section>

    <div class="container" style="margin-top: 20px;">
        <div class="row">
            <div class="col-md-6" style=" ">
                <a href="#"><img src="assets2/img/blog-img/img7.jpg" alt=""></a>
            </div>
            <div class="col-md-6" style="">
                <h1 class="text-center" style="font-family: 'Merriweather', cursive; font-weight: bold; color: #E5C12F; margin-top: 70px;">About Us</h1>
                <h5 class="text-center" style="font-family: 'Merriweather', cursive; color: #E5C12F; margin-top: 50px;">The icons fashion show is a platform created to build a high fashion standard in our society and as well promote fashion designers. The show will cover fashion designers from aspect. It has been packaged with an award show which aim is to celebrate ICONS.</h5>
            </div>
        </div>
    </div>
    <!-- ##### Blog Content Area Start ##### -->
    <section class="blog-content-area section-padding-0-100">
        <h1 class="text-center mt-50" style="color: #E5C12F; font-family: 'Merriweather', cursive; font-weight: bold;" >Latest Event</h1>
        <div class="container">
          <div class="row justify-content-center">
              <!-- Blog Posts Area -->
              <div class="col-12 col-lg-8">
                  <div class="blog-posts-area">
                      <div class="single-blog-post d-flex flex-wrap mt-50">
                          <!-- Thumbnail -->
                          <div class="post-thumbnail mb-50">
                              <a href="#"><img src="assets2/img/blog-img/img7.jpg" alt=""></a>
                          </div>
                          <!-- Content -->
                          <div class="post-content mb-50">
                              <p class="post-date" style="font-family: 'Merriweather', cursive; color: #E5C12F;">August 24, 2019 / Icon</p>
                              <a href="#" class="post-title">
                                  <h3>Icons fashion show and awards 2019</h3>
                              </a>
                              <div class="time">
                                  <span><i class="fa fa-clock-o" style=" font-size: 25px;"></i>
                                      <span style="margin-left: 10px; font-size: 16px; font-family: 'Merriweather', serif; font-weight: bold; color: #E5C12F;">1pm (Red carpet)</span>
                                  </span><br>
                                  <span style="margin-left: 35px; font-size: 16px; font-family: 'Merriweather', serif; font-weight: bold; color: #E5C12F;">2pm (Main Event)
                                  </span><br>

                                  <span><i class="fa fa-map-marker" style=" font-size: 25px;"></i><span style="margin-left: 15px; font-family: 'Merriweather', serif; font-weight: bold; color: #E5C12F; font-size: 16px;">Atimagies hotel,along Ogbomosho-Ilorin express road
                                  </span></span>
                                  <!-- <a href="#"><i class="fa "></i></a> -->
                              </div>
                              <div class="post-share text-center">
                          
                                  <a href="https://Fb.me/theiconsfashionshow"><i class="fa fa-facebook" aria-hidden="true" style="font-size: 25px;"></i></a>
                                  <a href="#"><i class="fa fa-instagram" aria-hidden="true" style="font-size: 25px;margin-left: 15px; color: black"></i></a>
                                  <!-- <a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a> -->
                              </div>
                          </div>
                          <!-- Post Curve Line -->
                          <img class="post-curve-line" src="assets2/img/core-img/post-curve-line.png" alt="">
                      </div>
                  </div>

              </div>

              <!-- Blog Sidebar Area -->
              <div class="col-12 col-sm-9 col-md-6 col-lg-4">
                  <div class="post-sidebar-area">
                      <!-- ##### Single Widget Area ##### -->
                      <div class="single-widget-area">
                          <!-- Title -->
                          <div class="widget-title">
                              <h6>Features</h6>
                          </div>
                          <!-- Tags -->
                          <ol class="popular-tags d-flex flex-wrap">
                              <li><a href="#">Runway Shows</a></li>
                              <li><a href="#">Brand Promotion</a></li>
                              <li><a href="#">Awards</a></li>
                              <li><a href="#">Exhibitions</a></li>
                              
                              
                          </ol>
                      </div>

                  </div>
              </div>
          </div>
        </div>
    </section>  

    <div class="container">
        <div class="container card leave-comment-area clearfix" style="background-color: rgba(21, 17, 17, 0.21);">
            <div class="comment-form">
                <h4 class="headline card-title text-center" style="font-family: 'Merriweather', cursive; margin-top: 20px;">Login</h4>
                <?php 
                    if(isset($_SESSION['msg'])){ ?>
                      <div class="card error" style="color: white; border-radius: 0px; background: linear-gradient(60deg, #ec407a, #d81b60); text-align: center; font-size: 17px; padding-top: 5px; padding-bottom: 5px;">
                        <?php echo $_SESSION['msg']; ?>

                        </div>
                    <?php }
                      session_destroy(); 
                    ?>
                <form action="server/call.php" method="post" id="form">
                    <div class="row">
                        <div class="col-12 col-md-12">
                            <div class="form-group">
                                <input type="email" class="form-control" id="contact-email" placeholder="Email" name="email">
                            </div>
                        </div>
                        <div class="col-12 col-md-12">
                            <div class="form-group">
                                <input type="password" class="form-control" id="contact-name" placeholder="Password" name="password">
                            </div>
                        </div>
                        
                        <div class="col-12">
                            <input type="submit" name="login" class="btn btn-round mt-4 mb-4" value="Login" style="background-color:#E5C12F;font-family: 'Merriweather', cursive;">
                        </div>
                    </div>
                </form>
            </div>  
        </div>
    </div>

    <div class="" style="text-align: center; margin-top: 30px;">
        <h3>Sponsored By</h3>
        <img src="assets/img/kad.jpg" style="height: 40px;">
        <img src="assets/img/kad2.jpg" style="height: 40px;">
    </div>

    <p style="float: right; margin-right: 100px;">Made  with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#">&lt/DevLekan&gt</a></p>

    <script src="assets2/js/jquery/jquery-2.2.4.min.js"></script>
    <script src="assets2/js/bootstrap/popper.min.js"></script>
    <script src="assets2/js/bootstrap/bootstrap.min.js"></script>
    <script src="assets2/js/plugins/plugins.js"></script>
    <script src="assets2/js/active.js"></script>
</body>

</html>